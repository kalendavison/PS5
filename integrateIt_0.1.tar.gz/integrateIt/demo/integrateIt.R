dx <- 1:10
dy <- 11:20
integrateIt(xvalues = dx, yvalues = dy, start = dx[1], end = dy[10] , "Trapezoid")
integrateIt(xvalues = dx, yvalues = dy, start = dx[1], end = dy[10] , "Simpson")


